package pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.aventstack.extentreports.ExtentTest;

public class HeaderLink {
	
public WebDriver driver;
public ExtentTest test;
	
	public HeaderLink(WebDriver driver,ExtentTest test) {
		this.driver=driver;
		this.test=test;
		PageFactory.initElements(driver, this);
	}
	
	
	@FindBy(xpath="//div[@id='myheader']/div[1]/div")
	WebElement Link;
	
	public WebElement Links() {
		return Link;
	}
}
